//
//  FirstViewController.swift
//  SuperherosLaureates
//
//  Created by Moyer,David C on 4/12/19.
//  Copyright © 2019 David C. Moyer. All rights reserved.
//

import UIKit

class HeroTableView: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var laureateArray: UITableView!
    
    var superheroList:[String]?

    override func viewDidLoad() {
        super.viewDidLoad()
        //assigning the datasource and delegate
        self.laureateArray.dataSource = self
        self.laureateArray.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return superheroList?.count ?? 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let superheroCell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "Superheroes")!
        
        return superheroCell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let superheroHeaderCell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "SuperheroHeader")!
        
        return superheroHeaderCell
    }


}

