//
//  SecondViewController.swift
//  SuperherosLaureates
//
//  Created by Moyer,David C on 4/12/19.
//  Copyright © 2019 David C. Moyer. All rights reserved.
//

import UIKit

class LaureateTableView: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var laureateArray: UITableView!
    
    var laureateList:[String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //assigning the datasource and delegate
        self.laureateArray.dataSource = self
        self.laureateArray.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laureateList?.count ?? 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let laureateCell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "Laureates")!
        
        return laureateCell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let laureateHeaderCell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "LaureatesHeader")!
        
        return laureateHeaderCell
    }
    
    
}



