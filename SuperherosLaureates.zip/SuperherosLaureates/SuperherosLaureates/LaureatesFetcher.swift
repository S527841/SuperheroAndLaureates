//
//  LaureatesFetcher.swift
//  SuperherosLaureates
//
//  Created by Moyer,David C on 4/12/19.
//  Copyright © 2019 David C. Moyer. All rights reserved.
//

import Foundation

class LaureatesFetcher {

    var openLaureatesURL:String = ""
    
    func fetchLaureates() -> Void {
        openLaureatesURL = "https://www.dropbox.com/s/7dhdrygnd4khgj2/laureates.json?dl=1"
        print(openLaureatesURL)
        let urlSession = URLSession.shared
        let url = URL(string: openLaureatesURL)
        urlSession.dataTask(with: url!, completionHandler: displayLaureates).resume()
    }

    
    func displayLaureates(data:Data?, urlResponse:URLResponse?, error:Error?) -> Void {
        var laureates:[String:Any]!
        do {
            try laureates =
                JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String:Any]
            if laureates != nil {
                let allLaureates = laureates["laureates"] as? [String:Double]
            }
        } catch {
            print(error)
        }
    }
}



