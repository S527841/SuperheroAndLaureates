//
//  SuperheroFetcher.swift
//  SuperherosLaureates
//
//  Created by Moyer,David C on 4/12/19.
//  Copyright © 2019 David C. Moyer. All rights reserved.
//

import Foundation

class SuperheroFetcher {
   /*
    var openSuperheroNamesURL:String = ""
    
    //called to start the Superhero fetching process
    func fetchSuperheroNames() -> Void {
        openSuperheroNamesURL = "https://www.dropbox.com/s/wpz5yu54yko6e9j/squad.json?dl=1" 
        print(openSuperheroNamesURL)
        let urlSession = URLSession.shared
        let url = URL(string: openSuperheroNamesURL)
        urlSession.dataTask(with: url!, completionHandler: displayNames).resume()
    }
    
    func displayNames(data:Data?, urlResponse:URLResponse?, error:Error?) -> Void {
        var superheroNames:[String:Any]!
        do {
            try superheroNames =
                /*JSONDecoder(with: data!, options: .allowFragments) as? [String:Any]
                */
            if superheroNames != nil {
                let allNames = superheroNames["name"] as? [String:Double]
            }
        } catch {
            print(error)
        }
    }
 */
}


